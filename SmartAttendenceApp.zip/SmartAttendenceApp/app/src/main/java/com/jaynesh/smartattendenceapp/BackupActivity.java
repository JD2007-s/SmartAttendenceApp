package com.jaynesh.smartattendenceapp;

import android.app.Activity;

public class BackupActivity extends Activity {
}
